require 'rails_helper'

RSpec.describe AuthenticationController, type: :controller do

end
