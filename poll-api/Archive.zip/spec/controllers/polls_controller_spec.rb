require 'rails_helper'

RSpec.describe PollsController, type: :controller do

end
